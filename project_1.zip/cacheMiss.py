def hovedprogram():
    print("Utregning av cache-hit og cache-miss. Utregningen fungerer ikke om det er cache miss i mer enn én cache, og regner heller ikke ut en påfølgende RAM-miss/hit")
    print()
    antallInstruksjoner = int(input("Antall instruksjoner: "))
    standardProsHast = int(input("Standard prosesseringshastighet (1 klokkesyklus per instruksjon = '1'): "))
    minneaksess = float(input("Minneaksessering (50% / '0.5'): ").strip("%"))
    if minneaksess > 1:
        minneaksess = minneaksess/100
    cacheMiss = float(input("Cache-MISS (70% / '0.7'): ").strip("%"))
    if cacheMiss > 1:
        cacheMiss = cacheMiss/100
    hitTillegg = int(input("Tillegg ved cache-HIT (2 per = 2): "))
    if hitTillegg > 0:
        hitStatus = int(input("Total forskinkelse = 1, tillegg forsinkelse (penalty) = 2: "))
    missTillegg = int(input("Tillegg ved cache-MISS (2 per = 2): "))
    missStatus = int(input("Total forskinkelse = 1, tillegg forsinkelse (penalty) = 2: "))

    sum = 0

    sum += (antallInstruksjoner-(antallInstruksjoner*minneaksess))*standardProsHast #Legger til de som ikke aksesserer minnet
    antallInstruksjoner = antallInstruksjoner - (sum/standardProsHast) #Gjenværende instruksjoner
    miss = antallInstruksjoner * cacheMiss
    hit = antallInstruksjoner-miss

    if hitTillegg > 0:
        if hitStatus == 1: #Total forskinkelse
            sum += hitTillegg * hit
        elif hitStatus == 2: #Tillegg forsinkelse
            sum += (hitTillegg * hit) + (standardProsHast * hit) #Tillegg pluss standard forsinkelse
        else:
            exit()
    if hitTillegg == 0:
        sum += hit * standardProsHast

    if missStatus == 1:
        sum += missTillegg * miss
    elif missStatus == 2:
        sum += (missTillegg * miss) + (standardProsHast * miss)

    if sum >= 10000:
        sum = int(sum)
        sum = str(sum)[::-1] #Skriver sum baklengs
        ny = ""
        while len(sum) > 3:
            for i in range(3):
                ny += sum[0]
                sum = sum[1:]
            ny+= "."
        sum = sum[::-1]
        sum += ny[::-1]

    print("Totalt antall klokkesykluser:", sum)
