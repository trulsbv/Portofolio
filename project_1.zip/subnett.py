import math
def subnett():
    ip = input("Maskinens IP-adresse (192.168.1.5): ")
    nettverksmaske = input("Nettverksmaske (255.255.255.0): ")

    ipSplittet = ip.split(".")
    nmSplittet = nettverksmaske.split(".")

    print()#Tomrom
    ipBi = binary(ipSplittet)
    nmBi = binary(nmSplittet)
    print("IP-Binær:", ipBi)
    print("Nettverksmaske-binær:", nmBi)
    print() #Tomrom
    print("Subnettadressen:", andOp(ipBi, nmBi))

    andOp(ipBi, nmBi)
def binary(input):
    output = []
    for i in range(len(input)):
        tall = int(input[i])
        sum = []
        while tall != 0:
            svar = float(tall/2) #Tallene etter komma skal bli brukt i svaret
            tall = math.floor(svar)
            sum += str((int((svar - tall)*2))) #Appender komma tallet
        for j in range(8):
            if len(sum) < 8:
                sum.append("0")

        sum.reverse()

        tall = ""
        for j in range(len(sum)):
            tall += sum[j]
        output.append(tall)
    return output

def andOp(ip, nm):
    assert len(ip) == len(nm)
    output = ""
    for i in range(len(ip)):
        for j in range(len(ip[i])):
            if (ip[i][j] == nm[i][j]) and ip[i][j] == "1":
                output += "1"
            else:
                output += "0"
            if j == 7:
                output += "."
    output = output[:-1]
    return output

def hovedprogram():
    subnett()
