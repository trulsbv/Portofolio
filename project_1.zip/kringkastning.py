import math
def subnett():
    ip = input("Maskinens IP-adresse (192.168.1.5): ")
    nettverksmaske = input("Nettverksmaske (255.255.255.0): ")

    ipSplittet = ip.split(".")
    nmSplittet = nettverksmaske.split(".")

    print()#Tomrom
    ipBi = binary(ipSplittet)
    nmBi = binary(nmSplittet)
    nmBiInv = invers(nmBi)
    print("IP-Binær:", ipBi)
    print("Nettverksmaske-binær:", nmBi)
    print("Nettverksmaske-binær (invertert):", nmBiInv)
    print() #Tomrom
    print("Kringkastningsadressen:", orOp(ipBi, nmBiInv))
    print()

    orOp(ipBi, nmBi)

def invers(input):
    output = []
    for i in range(len(input)):
        sum = ""
        for tall in input[i]:
            if tall == "0":
                sum += "1"
            else:
                sum += "0"
        output.append(sum)
    return output



def binary(input):
    output = []
    for i in range(len(input)):
        tall = int(input[i])
        sum = []
        while tall != 0:
            svar = float(tall/2) #Tallene etter komma skal bli brukt i svaret
            tall = math.floor(svar)
            sum += str((int((svar - tall)*2))) #Appender komma tallet
        for j in range(8):
            if len(sum) < 8:
                sum.append("0")

        sum.reverse()

        tall = ""
        for j in range(len(sum)):
            tall += sum[j]
        output.append(tall)
    return output

def orOp(ip, nm): #MÅ ENDRES FRA EN AND TIL EN OR
    assert len(ip) == len(nm)
    output = ""
    for i in range(len(ip)):
        for j in range(len(ip[i])):
            if (ip[i][j] == "1") or (nm[i][j] == "1"):
                output += "1"
            else:
                output += "0"
            if j == 7:
                output += "."
    output = output[:-1]
    return output

def hovedprogram():
    subnett()
