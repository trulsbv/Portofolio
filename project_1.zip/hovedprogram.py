import cacheMiss
import subnett
import kringkastning
import GHz
def hovedprogram():
    funksjoner = ["Regne ut subnett", "Regne ut kringkastningsadressen", "Regne ut cache-miss", "Regne ut GHz"]

    funksjoner.append("Avslutt")
    lock = False
    print(len(funksjoner))
    while lock == False:
        print()
        print("Velg ønsket funksjon: ")
        print()
        for i in range(len(funksjoner)):
            print(f"{i+1}. {funksjoner[i]}")
        print()
        valg = int(input("Valg: "))
        if valg == 1:
            print(funksjoner[int(valg)-1])
            subnett.hovedprogram()
        if valg == 2:
            print(funksjoner[int(valg)-1])
            kringkastning.hovedprogram()

        if valg == 3:
            print(funksjoner[int(valg)-1])
            cacheMiss.hovedprogram()

        if valg == 4:
            print(funksjoner[int(valg)-1])
            GHz.hovedprogram()

        if valg == len(funksjoner):
            exit()
hovedprogram()
