import math
                #     70          5
def finnFrekvens(klokkeperiode, delay):
    klokkeperiode = klokkeperiode/100
    sum = float(delay/klokkeperiode)
    sum = math.ceil(sum)
    sum = float(sum/1000)
    sum = 1/sum
    print(sum, "GHz")

def finnKlokkeperiode(delay, frekvens):
    sum = float(1/frekvens)
    sum = sum*1000
    print("Sum", sum)
    sum2 = sum-1
    sum = (delay/sum)*100
    sum2 = (delay/sum2)*100

    print("Klokkeperioden er mellom " + str(sum) + "% og " + str(sum2) + "% hoy")

def finnDelay(klokkeperiode, frekvens):
    sum = float(1/frekvens)
    sum = sum*10
    sum = (sum*klokkeperiode)
    print("Delay: " + str(sum))

def hovedprogram():
    sjekkSum = 0
    while sjekkSum != 2:
        sjekkSum = 0
        print("Skriv 'X' i den du vil vite verdien av\n")
        klokkeperiode = input("Klokkeperiode hoy (70% hoy = 70): ").lower()
        delay = input("Totalt delay (15ps delay = 15): ").lower()
        frekvens = input("Frekvens i GHz (125GHz = 125): ").lower()

        sjekk = [klokkeperiode, delay, frekvens]
        for ord in sjekk:
            if ord != "x":
                sjekkSum += 1

        if sjekkSum != 2:
            print("Du maa ha én x")

    if sjekk[0] == "x":
        delay = float(delay)
        frekvens = float(frekvens)
        finnKlokkeperiode(delay, frekvens)
    if sjekk[1] == "x":
        klokkeperiode = float(klokkeperiode)
        frekvens = float(frekvens)
        finnDelay(klokkeperiode, frekvens)
    if sjekk[2] == "x":
        delay = float(delay)
        klokkeperiode = float(klokkeperiode)
        finnFrekvens(klokkeperiode, delay)
