def inverter(tall):
    if tall == 0:
        return 1
    else:
        return 0

def regnUt(A, B, operator):
    if operator == "AND":
        if A == 1 and A == B:
            return 1
        else:
            return 0
    elif operator == "OR":
        if A == 1 or B == 1:
            return 1
        else:
            return 0
    elif operator == "INV" or operator == "NOT":
        if A == 0:
            return 1
        else:
            return 0
    elif operator == "XOR":
        if A != B:
            return 1
        else:
            return 0
    elif operator == "XNOR":
        if A == B:
            return 1
        else:
            return 0
    elif operator == "NOR":
        if A == 0 and A == B:
            return 1
        else:
            return 0
    elif operator == "NAND":
        if A == 0 or B == 0:
            return 1
        else:
            return 0


def hovedprogram():
    operatorer = ["AND", "OR", "XOR", "XNOR", "NOR", "NAND"] #NOT og INV er det samme

    enVar = [["A"],[0],[1]]
            #[A],
            #[0],
            #[1]
    toVar = [["A", "B"],[0,0],[0,1],[1,0],[1,1]]
            #[A,B]
            #[0,0],
            #[0,1],
            #[1,0],
            #[1,1]
    treVar = [["A", "B", "C"],[0,0,0],[0,0,1],[0,1,0],[0,1,1],[1,0,0],[1,0,1],[1,1,0],[1,1,1]]
            #[A,B,C]
            #[0,0,0],
            #[0,0,1],
            #[0,1,0],
            #[0,1,1],
            #[1,0,0],
            #[1,0,1],
            #[1,1,0],
            #[1,1,1]

    antallVariabler = []
    variabelRekkefolge = []
    invertPlassering = []
    lagreOperator = []
    innVerdi = input("Krets (A OR B AND C! [! = NOT]): ").upper().split()
    i = 0
    for ord in innVerdi:
        if ord not in operatorer:
            variabelRekkefolge.append(ord)

            if ord not in antallVariabler:
                antallVariabler.append(ord)
        else:
            lagreOperator.append(ord)
        if ord == "INV" or ord == "NOT":
            invertPlassering.append(i)
        i += 1
    print("\n=======\nInformasjon:")
    print(antallVariabler)
    print(lagreOperator)
    print("=======")

    if len(antallVariabler) == 1:
        var = enVar
    if len(antallVariabler) == 2:
        var = toVar
    if len(antallVariabler) == 3:
        var = treVar

    svar = 10
    rekkefolgeTall = []
    lagreTall = []
    listeMedSvar = []

    for i in range(2**len(antallVariabler)):
        i += 1 #Hopper over første linje, der bokstavene står
        liste = []
        for j in range(len(antallVariabler)):
            liste.append(var[i][j])
            lagreTall.append(var[i][j])
        rekkefolgeTall.append(liste)

    i = 0
#OBS! Den må kunne lese parenteser, for A + BC er ikke lik BC + A


    while i != len(rekkefolgeTall): #Starter hver rad
        operatorRekkefolge = []
        for verdi in lagreOperator:
            operatorRekkefolge.append(verdi)
        x = len(rekkefolgeTall[0])
        bokstav = variabelRekkefolge[0]
        if bokstav == "A":
            svar = rekkefolgeTall[i][0]
        elif bokstav == "B":
            svar = rekkefolgeTall[i][1]
        elif bokstav == "C":
            svar = rekkefolgeTall[i][2]
        elif bokstav == "A!":
            svar = inverter(rekkefolgeTall[i][0])
        elif bokstav == "B!":
            svar = inverter(rekkefolgeTall[i][1])
        elif bokstav == "C!":
            svar = inverter(rekkefolgeTall[i][2])

        j = 0
        while j < len(operatorRekkefolge):
            if j+1 != len(variabelRekkefolge):
                bokstav = variabelRekkefolge[j+1]
                if bokstav == "A":
                    tall = rekkefolgeTall[i][0]
                elif bokstav == "B":
                    tall = rekkefolgeTall[i][1]
                elif bokstav == "C":
                    tall = rekkefolgeTall[i][2]
                elif bokstav == "A!":
                    tall = inverter(rekkefolgeTall[i][0])
                elif bokstav == "B!":
                    tall = inverter(rekkefolgeTall[i][0])
                elif bokstav == "C!":
                    tall = inverter(rekkefolgeTall[i][0])
            if len(operatorRekkefolge) > j+1:
                if operatorRekkefolge[j+1] == "AND": #Hvis neste logiske argument er AND
                    bokstav = variabelRekkefolge[j+1] #Henter bokstaven før AND
                    if bokstav == "A":
                        tall1 = rekkefolgeTall[i][0]
                    elif bokstav == "B":
                        tall1 = rekkefolgeTall[i][1]
                    elif bokstav == "C":
                        tall1 = rekkefolgeTall[i][2]
                    elif bokstav == "A!":
                        tall1 = inverter(rekkefolgeTall[i][0])
                    elif bokstav == "B!":
                        tall1 = inverter(rekkefolgeTall[i][0])
                    elif bokstav == "C!":
                        tall1 = inverter(rekkefolgeTall[i][0])
                    bokstav = variabelRekkefolge[j+2] #Henter bokstaven etter AND

                    if bokstav == "A":
                        tall2 = rekkefolgeTall[i][0]
                    elif bokstav == "B":
                        tall2 = rekkefolgeTall[i][1]
                    elif bokstav == "C":
                        tall2 = rekkefolgeTall[i][2]
                    elif bokstav == "A!":
                        tall2 = inverter(rekkefolgeTall[i][0])
                    elif bokstav == "B!":
                        tall2 = inverter(rekkefolgeTall[i][0])
                    elif bokstav == "C!":
                        tall2 = inverter(rekkefolgeTall[i][0])

                    mellom = regnUt(tall1, tall2, operatorRekkefolge[j+1]) #Regner ut x AND y
                    svar = regnUt(mellom, svar, operatorRekkefolge[j]) #Regner ut a _ (x AND y)
                else:
                    svar = regnUt(svar, tall, operatorRekkefolge[j])
            else:
                svar = regnUt(svar, tall, operatorRekkefolge[j])
            j += 1
        listeMedSvar.append(svar)
        j = 0
        i += 1
        
    j = 0
    for i in range(len(listeMedSvar)):
        if len(antallVariabler) == 1:
            print(lagreTall[j], lagreTall[j+1], "|",  listeMedSvar[i])
            j += 1
            print()
        if len(antallVariabler) == 2:
            print(antallVariabler[0], antallVariabler[1])
            print(lagreTall[j], lagreTall[j+1], "|", listeMedSvar[i])
            j += 2
            print()
        if len(antallVariabler) == 3:
            print(lagreTall[j], lagreTall[j+1], lagreTall[j+2], "|", listeMedSvar[i])
            if lagreTall[j] == 1 and lagreTall[j+1] == 1 and lagreTall[j+2] == 1:
                exit()
            j += 3
            print()


hovedprogram()
